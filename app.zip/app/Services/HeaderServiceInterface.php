<?php
namespace App\Services;

interface HeaderServiceInterface
{
    public function getModelUser();
    public function newTransaccion($referencia,$descripcion,$tipo);
}