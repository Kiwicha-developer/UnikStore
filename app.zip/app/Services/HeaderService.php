<?php
namespace App\Services;

use Illuminate\Support\Facades\DB;
use App\Models\Usuario;
use App\Models\Empresa;
use App\Models\Transaccion;

use Illuminate\Support\Facades\DB as DBase;

class HeaderService implements HeaderServiceInterface
{
    public function getModelUser(){
        $idUser = session()->get('idUser',-1);
        $userModel = Usuario::select('idUser','user','idCargo')->where('idUser','=',$idUser)->first();
        return $userModel;
    }
    
    public function newTransaccion($referencia,$descripcion,$tipo){
        $usuario = $this->getModelUser();
        $newId = $this->generateIdTransaccion();
        
        $transaccion = new Transaccion();
        $transaccion->idTransaccion = $newId;
        $transaccion->idUser = $usuario->idUser;
        $transaccion->referencia = $referencia;
        $transaccion->descripcion = $descripcion;
        $transaccion->tipo = $tipo;
        $transaccion->fechaTransaccion = now();
        
        $transaccion->save();
        
        return $transaccion;
    }
    
    private function generateIdTransaccion(){
        $id = Transaccion::select('idTransaccion')->orderBy('idTransaccion','desc')->first();
        return $id->idTransaccion + 1;
    }
}