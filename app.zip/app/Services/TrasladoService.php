<?php
namespace App\Services;

use App\Repositories\AlmacenRepositoryInterface;
use App\Repositories\InventarioRepositoryInterface;
use App\Repositories\RegistroProductoRepositoryInterface;

class TrasladoService implements TrasladoServiceInterface
{
    protected $almacenRepository;
    protected $registroRepository;
    protected $inventarioRepository;

    public function __construct(AlmacenRepositoryInterface $almacenRepository,
                                RegistroProductoRepositoryInterface $registroRepository,
                                InventarioRepositoryInterface $inventarioRepository)
    {
        $this->almacenRepository = $almacenRepository;
        $this->registroRepository = $registroRepository;
        $this->inventarioRepository = $inventarioRepository;
    }

    public function getAllAlmacenes(){
        return $this->almacenRepository->all();
    }

    public function updateRegistros(array $array){
        foreach($array as $idRegistro => $idAlmacen){
            if(isset($idAlmacen)){
                $data = ['idAlmacen' => $idAlmacen];
                $this->updateStock($idRegistro,$idAlmacen);
                $this->registroRepository->update($idRegistro,$data);
                
            }
            
        }
    }

    private function updateStock($idRegistro,$idAlmacen){
        $registro = $this->registroRepository->getOne('idRegistro',$idRegistro);
        //descontar
        $this->inventarioRepository->removeStock($registro->DetalleComprobante->idProducto,$registro->idAlmacen);
        //incrementar
        $this->inventarioRepository->addStock($registro->DetalleComprobante->idProducto,$idAlmacen);
    } 
}