<?php
namespace App\Services;
use App\Models\Comision;
use App\Repositories\ComisionRepositoryInterface;

class ComisionService implements ComisionServiceInterface{
    
    protected $comisionRepository;
    
    public function __construct(ComisionRepositoryInterface $comisionRepository){
        $this->comisionRepository = $comisionRepository;
    }
    public function getOneLabelCategory($idCategory){
        $comision = $this->ComisionRepository->getOne('idComision',$idComision)->only(['idComision', 'nombreComision']);
        return $comision;
        
    }
}


