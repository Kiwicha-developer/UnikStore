<?php
namespace App\Services;

use App\Models\TipoComprobante;
use App\Repositories\TipoComprobanteRepositoryInterface;

class TipoComprobanteService implements TipoComprobanteServiceInterface
{
    protected $tipoComprobanteRepository;
    
    public function __construct(TipoComprobanteRepositoryInterface $tipoComprobanteRepository)
    {
        $this->tipoComprobanteRepository = $tipoComprobanteRepository;
    }
    
    public function getAllTipoComprobante(){
        $tipoComprobante = TipoComprobante::all();
        return $tipoComprobante;
    }
    
}