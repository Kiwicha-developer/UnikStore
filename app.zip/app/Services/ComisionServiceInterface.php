<?php
namespace App\Services;

interface ComisionServiceInterface
{
    public function getOneLabelCategory($id);
}