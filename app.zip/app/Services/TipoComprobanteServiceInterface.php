<?php
namespace App\Services;

interface TipoComprobanteServiceInterface
{
    public function getAllTipoComprobante();
}