<?php
namespace App\Services;

use Illuminate\Support\Facades\DB;
use App\Models\Usuario;

use Illuminate\Support\Facades\DB as DBase;

class DocumentoService
{
    public function getIngresoXMonth($month){
        $ingreso = IngresoProducto::whereMonth('fechaIngreso', $month)
                                    ->orderBy('fechaIngreso','desc')
                                    ->get();
        return $ingreso;
    }
    
}