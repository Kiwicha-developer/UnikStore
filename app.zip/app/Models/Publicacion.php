<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Publicacion extends Model
{
    public $timestamps = false;
 
    protected $table = 'Publicacion';
    
    protected $primaryKey = 'idPublicacion';

    protected $guarded = ['idPublicacion'];
    
    protected $fillable = ['idPublicacion',
                            'idCuentaPlataforma',
                            'idUser',
                            'idProducto',
                            'sku',
                            'titulo',
                            'estado',
                            'fechaPublicacion',
                            'precioPublicacion'
                            ];

    
    protected $hidden = [
        
    ];

    
    protected $casts = [
        'idPublicacion' => 'int',
        'idCuentaPlataforma' => 'int',
        'idUser' => 'int',
        'idProducto' => 'int',
        'estado' => 'int',
        'fechaPublicacion' => 'date',
        'precioPublicacion' => 'decimal:9'
    ];
    
    public function CuentasPlataforma()
    {
        return $this->belongsTo(CuentasPlataforma::class,'idCuentaPlataforma','idCuentaPlataforma');
    }
    
    public function Usuario()
    {
        return $this->belongsTo(Usuario::class,'idUser','idUser');
    }
    
    public function Producto()
    {
        return $this->belongsTo(Producto::class,'idProducto','idProducto');
    }

    /**
     * Obtener las relaciones del modelo.
     */
    
}