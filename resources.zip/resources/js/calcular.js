function Cambiar(){
    let titulo = document.getElementById('proba');
    
    titulo.textContent = 'funka';
}