<div class="aviso_no_encontrado">
    <div class="row text-center">
            <div class="col-12 ">
                <h3 class="text-black-50">El articulo {{$mensaje}} no se encontr&oacute</h3>
                <a class="text-black-50" href="javascript:void(0)" onclick="window.history.back()">Regresar a la pagina anterior</a>
            </div>
        </div>
</div>