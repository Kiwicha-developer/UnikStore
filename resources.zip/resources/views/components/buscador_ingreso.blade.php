<div class="buscador_ingreso">
    <div class="row">
        <div class="input-group input-group-sm mb-3">
          <span class="input-group-text"><button class="btn btn-sm pb-0 mb-0"><i class="bx bx-search-alt bx-sm" ></i></button></span>
          <input type="text" class="form-control form-control-sm"  placeholder="Serial Number...">
        </div>
    </div>
</div>